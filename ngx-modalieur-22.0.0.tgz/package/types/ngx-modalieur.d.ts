import * as ngx_modalieur from 'ngx-modalieur';
import { CdkDialogContainer, DialogRef } from '@angular/cdk/dialog';
import * as i0 from '@angular/core';
import { InjectionToken, Type, EnvironmentProviders } from '@angular/core';
import { Observable } from 'rxjs';

/**
 * Default dialog container that wraps the projected modal content in Bootstrap
 * 5.3 markup (`.modal-dialog > .modal-content`) so every modal looks like a
 * native Bootstrap modal. The consumer component only renders the inner
 * `.modal-header` / `.modal-body` / `.modal-footer`.
 */
declare class BootstrapDialogContainer extends CdkDialogContainer {
    protected readonly options: ngx_modalieur.ModalConfig<unknown>;
    static ɵfac: i0.ɵɵFactoryDeclaration<BootstrapDialogContainer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BootstrapDialogContainer, "mdlr-bootstrap-dialog", never, {}, {}, never, never, true, never>;
}

declare enum MessageBoxButtons {
    OK = 0,
    OKCancel = 1,
    AbortRetryIgnore = 2,
    YesNoCancel = 3,
    YesNo = 4,
    RetryCancel = 5
}

/** Options for a config-driven `MessageBoxDialog`. */
interface MessageBoxOptions {
    title?: string;
    message?: string;
    /** Which buttons to render. Defaults to `MessageBoxButtons.OK`. */
    buttons?: MessageBoxButtons;
}

declare enum ModalResult {
    Undefined = 0,
    Data = 1,
    Yes = 2,
    No = 3,
    Ok = 4,
    Cancel = 5,
    Abort = 6,
    Retry = 7,
    Ignore = 8,
    AutoClose = 9
}

interface ModalOutcome<TData = unknown> {
    result: ModalResult;
    data?: TData;
}

declare class ModalRef<TDataOut = unknown> {
    private readonly dialogRef;
    readonly id: string;
    readonly closed$: Observable<ModalOutcome<TDataOut>>;
    constructor(dialogRef: DialogRef<ModalOutcome<TDataOut>, any>);
    close(result?: ModalResult, data?: TDataOut): void;
}

declare abstract class ModalContent<TDataOut = unknown> {
    protected readonly modalRef: ModalRef<TDataOut>;
    protected yes(data?: TDataOut): void;
    protected no(data?: TDataOut): void;
    protected ok(data?: TDataOut): void;
    protected cancel(data?: TDataOut): void;
    protected abort(data?: TDataOut): void;
    protected retry(data?: TDataOut): void;
    protected ignore(data?: TDataOut): void;
    protected respondWithData(data: TDataOut): void;
    protected close(result?: ModalResult, data?: TDataOut): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModalContent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<ModalContent<any>, never, never, {}, {}, never, never, true, never>;
}

interface MessageBoxButton {
    result: ModalResult;
    label: string;
    cssClass: string;
}

/** DOM id for the config-driven message-box title (used with aria-labelledby). */
declare const MESSAGE_BOX_TITLE_ID = "mdlr-message-box-title";
/** DOM id for the config-driven message-box body (used with aria-describedby). */
declare const MESSAGE_BOX_BODY_ID = "mdlr-message-box-body";
/**
 * A Bootstrap-styled message box. Use it two ways:
 *
 * 1. Config-driven — `modalieur.messageBox({ title, message, buttons })`.
 * 2. Content projection — place `<mdlr-message-box>` in your own component and
 *    project `[mbHeader]`, `[mbBody]`, `[mbFooter]`.
 */
declare class MessageBoxDialog extends ModalContent {
    protected readonly Result: typeof ModalResult;
    protected readonly titleId = "mdlr-message-box-title";
    protected readonly bodyId = "mdlr-message-box-body";
    private readonly options;
    protected get title(): string;
    protected get message(): string;
    protected get buttons(): MessageBoxButton[];
    static ɵfac: i0.ɵɵFactoryDeclaration<MessageBoxDialog, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MessageBoxDialog, "mdlr-message-box", never, {}, {}, never, ["[mbHeader]", "[mbBody]", "[mbFooter]"], true, never>;
}

type ModalSize = 'sm' | 'md' | 'lg' | 'xl' | 'fullscreen';

interface ModalConfig<TDataIn = unknown> {
    /** Data injected into the modal component via the `MODAL_DATA` token. */
    data?: TDataIn;
    /** Bootstrap dialog size. Omit for the default (medium) size. */
    size?: ModalSize;
    /** Vertically center the dialog (`.modal-dialog-centered`). Default: `true`. */
    centered?: boolean;
    /** Allow the modal body to scroll (`.modal-dialog-scrollable`). Default: `false`. */
    scrollable?: boolean;
    /**
     * Whether clicking the backdrop or pressing Escape closes the modal.
     * Default: `true`. Set to `false` for a non-dismissible (static) modal.
     */
    dismissible?: boolean;
    /** Whether a backdrop element is rendered. Default: `true`. */
    backdrop?: boolean;
    /**
     * Skip the Bootstrap dialog container and render the bare component instead.
     * Default: `false`.
     */
    unstyled?: boolean;
    /** Accessible label for the dialog (maps to CDK `ariaLabel`). */
    ariaLabel?: string | null;
    /** ID of the element that labels the dialog (maps to CDK `ariaLabelledBy`). */
    ariaLabelledBy?: string | null;
    /** ID of the element that describes the dialog (maps to CDK `ariaDescribedBy`). */
    ariaDescribedBy?: string | null;
}

declare const MODAL_DATA: InjectionToken<unknown>;

/** Built-in defaults merged with per-call config and app-wide overrides. */
declare const MODALIEUR_DEFAULTS: Readonly<ModalConfig>;

type ModalResultData<C> = C extends ModalContent<infer TData> ? TData : unknown;

/**
 * Opens Bootstrap-styled modals on top of Angular CDK `Dialog` and exposes the
 * result reactively. The modal is a regular component; close it from inside via
 * `ModalContent` helpers (or by injecting `ModalRef`).
 */
declare class ModalieurService {
    private readonly cdkDialog;
    private readonly modalieurConfig;
    /**
     * Opens a modal and emits its outcome when it closes. `TIn` is the input data
     * type (from `config.data`); the result-data type is inferred from the
     * component's `ModalContent` base.
     */
    show<C, TIn = unknown>(component: Type<C>, config?: ModalConfig<TIn>): Observable<ModalOutcome<ModalResultData<C>>>;
    /**
     * Opens a modal that auto-closes on the **first emission** from `until$`,
     * regardless of value (`false`, `0`, and `''` all count).
     *
     * Use this for timers, one-shot events, or "close when anything happens".
     * For "close when ready", use {@link showUntilCondition} instead.
     *
     * Closes with {@link ModalResult.AutoClose}.
     */
    showUntil<C, TIn = unknown>(component: Type<C>, until$: Observable<unknown>, config?: ModalConfig<TIn>): Observable<ModalOutcome<ModalResultData<C>>>;
    /**
     * Opens a modal that auto-closes on the **first truthy** emission from
     * `condition$`. Falsy values (`false`, `0`, `''`, `null`, `undefined`) are
     * ignored until a truthy value arrives.
     *
     * Use this for async readiness signals (e.g. `saveComplete$`, `loaded$`).
     * For "close on any emission", use {@link showUntil} instead.
     *
     * Closes with {@link ModalResult.AutoClose}.
     */
    showUntilCondition<C, TIn = unknown>(component: Type<C>, condition$: Observable<unknown>, config?: ModalConfig<TIn>): Observable<ModalOutcome<ModalResultData<C>>>;
    /** Opens a modal and returns its `ModalRef` for programmatic control. */
    showAndReturnRef<C, TIn = unknown>(component: Type<C>, config?: ModalConfig<TIn>): ModalRef<ModalResultData<C>>;
    /**
     * Opens a config-driven {@link MessageBoxDialog} and emits only the
     * `ModalResult` (not the full `ModalOutcome`).
     */
    messageBox(options: MessageBoxOptions, config?: Omit<ModalConfig<MessageBoxOptions>, 'data'>): Observable<ModalResult>;
    /** Yes / No confirmation. Shorthand for `messageBox` with `MessageBoxButtons.YesNo`. */
    confirm(title: string, message?: string, config?: Omit<ModalConfig<MessageBoxOptions>, 'data'>): Observable<ModalResult>;
    /** Single OK button alert. Shorthand for `messageBox` with `MessageBoxButtons.OK`. */
    alert(title: string, message?: string, config?: Omit<ModalConfig<MessageBoxOptions>, 'data'>): Observable<ModalResult>;
    private toDialogConfig;
    private withMessageBoxA11y;
    static ɵfac: i0.ɵɵFactoryDeclaration<ModalieurService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ModalieurService>;
}

/** App-wide default `ModalConfig`, merged with (and overridden by) per-call config. */
declare const MODALIEUR_CONFIG: InjectionToken<ModalConfig<unknown>>;
/**
 * Registers ngx-modalieur defaults. Add to an application's providers to set
 * app-wide modal behavior, e.g. to make every modal non-dismissible:
 *
 * @example
 * ```ts
 * providers: [provideModalieur({ dismissible: false, size: 'lg' })]
 * ```
 */
declare function provideModalieur(defaults?: ModalConfig): EnvironmentProviders;

export { BootstrapDialogContainer, MESSAGE_BOX_BODY_ID, MESSAGE_BOX_TITLE_ID, MODALIEUR_CONFIG, MODALIEUR_DEFAULTS, MODAL_DATA, MessageBoxButtons, MessageBoxDialog, ModalContent, ModalRef, ModalResult, ModalieurService, provideModalieur };
export type { MessageBoxOptions, ModalConfig, ModalOutcome, ModalResultData, ModalSize };
