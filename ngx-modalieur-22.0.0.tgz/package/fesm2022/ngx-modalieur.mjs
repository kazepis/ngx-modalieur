import { CdkDialogContainer, Dialog, DialogRef } from '@angular/cdk/dialog';
import { CdkPortalOutlet } from '@angular/cdk/portal';
import * as i0 from '@angular/core';
import { InjectionToken, makeEnvironmentProviders, inject, ChangeDetectionStrategy, ViewEncapsulation, Component, Directive, signal, Injectable } from '@angular/core';
import { map, take, takeUntil, filter } from 'rxjs';

/** Built-in defaults merged with per-call config and app-wide overrides. */
const MODALIEUR_DEFAULTS = {
    backdrop: true,
    centered: true,
    dismissible: true,
    scrollable: false,
    unstyled: false
};

/** App-wide default `ModalConfig`, merged with (and overridden by) per-call config. */
const MODALIEUR_CONFIG = new InjectionToken('ngx-modalieur.CONFIG');
/**
 * Registers ngx-modalieur defaults. Add to an application's providers to set
 * app-wide modal behavior, e.g. to make every modal non-dismissible:
 *
 * @example
 * ```ts
 * providers: [provideModalieur({ dismissible: false, size: 'lg' })]
 * ```
 */
function provideModalieur(defaults) {
    return makeEnvironmentProviders([
        {
            provide: MODALIEUR_CONFIG,
            useValue: defaults ?? MODALIEUR_DEFAULTS
        }
    ]);
}

/**
 * Default dialog container that wraps the projected modal content in Bootstrap
 * 5.3 markup (`.modal-dialog > .modal-content`) so every modal looks like a
 * native Bootstrap modal. The consumer component only renders the inner
 * `.modal-header` / `.modal-body` / `.modal-footer`.
 */
class BootstrapDialogContainer extends CdkDialogContainer {
    options = inject(MODALIEUR_CONFIG, { optional: true }) ?? {};
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.2", ngImport: i0, type: BootstrapDialogContainer, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "22.0.2", type: BootstrapDialogContainer, isStandalone: true, selector: "mdlr-bootstrap-dialog", usesInheritance: true, ngImport: i0, template: `
    <div class="modal" tabindex="-1">
      <div
        class="modal-dialog"
        [class.modal-dialog-centered]="options.centered !== false && !options.scrollable"
        [class.modal-dialog-scrollable]="!!options.scrollable"
        [class.modal-sm]="options.size === 'sm'"
        [class.modal-lg]="options.size === 'lg'"
        [class.modal-xl]="options.size === 'xl'"
        [class.modal-fullscreen]="options.size === 'fullscreen'"
      >
        <div class="modal-content">
          <ng-template cdkPortalOutlet />
        </div>
      </div>
    </div>
  `, isInline: true, dependencies: [{ kind: "directive", type: CdkPortalOutlet, selector: "[cdkPortalOutlet]", inputs: ["cdkPortalOutlet"], outputs: ["attached"], exportAs: ["cdkPortalOutlet"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.2", ngImport: i0, type: BootstrapDialogContainer, decorators: [{
            type: Component,
            args: [{
                    selector: 'mdlr-bootstrap-dialog',
                    standalone: true,
                    imports: [CdkPortalOutlet],
                    // The `.modal` wrapper is required: Bootstrap declares the `--bs-modal-*`
                    // CSS variables (background, padding, width, etc.) on `.modal`, and provides
                    // the full-screen context for `.modal-dialog` centering/sizing.
                    template: `
    <div class="modal" tabindex="-1">
      <div
        class="modal-dialog"
        [class.modal-dialog-centered]="options.centered !== false && !options.scrollable"
        [class.modal-dialog-scrollable]="!!options.scrollable"
        [class.modal-sm]="options.size === 'sm'"
        [class.modal-lg]="options.size === 'lg'"
        [class.modal-xl]="options.size === 'xl'"
        [class.modal-fullscreen]="options.size === 'fullscreen'"
      >
        <div class="modal-content">
          <ng-template cdkPortalOutlet />
        </div>
      </div>
    </div>
  `,
                    // The Bootstrap `.modal-*` classes are global; disable encapsulation so the
                    // container does not scope them away.
                    encapsulation: ViewEncapsulation.None,
                    changeDetection: ChangeDetectionStrategy.OnPush
                }]
        }] });

var MessageBoxButtons;
(function (MessageBoxButtons) {
    MessageBoxButtons[MessageBoxButtons["OK"] = 0] = "OK";
    MessageBoxButtons[MessageBoxButtons["OKCancel"] = 1] = "OKCancel";
    MessageBoxButtons[MessageBoxButtons["AbortRetryIgnore"] = 2] = "AbortRetryIgnore";
    MessageBoxButtons[MessageBoxButtons["YesNoCancel"] = 3] = "YesNoCancel";
    MessageBoxButtons[MessageBoxButtons["YesNo"] = 4] = "YesNo";
    MessageBoxButtons[MessageBoxButtons["RetryCancel"] = 5] = "RetryCancel";
})(MessageBoxButtons || (MessageBoxButtons = {}));

var ModalResult;
(function (ModalResult) {
    ModalResult[ModalResult["Undefined"] = 0] = "Undefined";
    ModalResult[ModalResult["Data"] = 1] = "Data";
    ModalResult[ModalResult["Yes"] = 2] = "Yes";
    ModalResult[ModalResult["No"] = 3] = "No";
    ModalResult[ModalResult["Ok"] = 4] = "Ok";
    ModalResult[ModalResult["Cancel"] = 5] = "Cancel";
    ModalResult[ModalResult["Abort"] = 6] = "Abort";
    ModalResult[ModalResult["Retry"] = 7] = "Retry";
    ModalResult[ModalResult["Ignore"] = 8] = "Ignore";
    ModalResult[ModalResult["AutoClose"] = 9] = "AutoClose";
})(ModalResult || (ModalResult = {}));

class ModalRef {
    dialogRef;
    id;
    closed$;
    constructor(dialogRef) {
        this.dialogRef = dialogRef;
        this.id = dialogRef.id;
        this.closed$ = dialogRef.closed.pipe(map(outcome => outcome ?? { result: ModalResult.Cancel }));
    }
    close(result = ModalResult.Undefined, data) {
        this.dialogRef.close({ result, data });
    }
}

class ModalContent {
    modalRef = inject(ModalRef);
    yes(data) {
        this.close(ModalResult.Yes, data);
    }
    no(data) {
        this.close(ModalResult.No, data);
    }
    ok(data) {
        this.close(ModalResult.Ok, data);
    }
    cancel(data) {
        this.close(ModalResult.Cancel, data);
    }
    abort(data) {
        this.close(ModalResult.Abort, data);
    }
    retry(data) {
        this.close(ModalResult.Retry, data);
    }
    ignore(data) {
        this.close(ModalResult.Ignore, data);
    }
    respondWithData(data) {
        this.close(ModalResult.Data, data);
    }
    close(result = ModalResult.Undefined, data) {
        this.modalRef.close(result, data);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.2", ngImport: i0, type: ModalContent, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "22.0.2", type: ModalContent, isStandalone: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.2", ngImport: i0, type: ModalContent, decorators: [{
            type: Directive
        }] });

const MODAL_DATA = new InjectionToken('ngx-modalieur.MODAL_DATA');

/** Single source of truth for message-box button labels and Bootstrap classes. */
const MESSAGE_BOX_BUTTON = {
    [ModalResult.Ok]: { label: 'OK', cssClass: 'btn-primary' },
    [ModalResult.Cancel]: { label: 'Cancel', cssClass: 'btn-secondary' },
    [ModalResult.No]: { label: 'No', cssClass: 'btn-secondary' },
    [ModalResult.Yes]: { label: 'Yes', cssClass: 'btn-primary' },
    [ModalResult.Abort]: { label: 'Abort', cssClass: 'btn-danger' },
    [ModalResult.Retry]: { label: 'Retry', cssClass: 'btn-primary' },
    [ModalResult.Ignore]: { label: 'Ignore', cssClass: 'btn-secondary' }
};
const MESSAGE_BOX_BUTTON_SETS = {
    [MessageBoxButtons.OK]: [ModalResult.Ok],
    [MessageBoxButtons.OKCancel]: [ModalResult.Ok, ModalResult.Cancel],
    [MessageBoxButtons.AbortRetryIgnore]: [ModalResult.Abort, ModalResult.Retry, ModalResult.Ignore],
    [MessageBoxButtons.YesNoCancel]: [ModalResult.Yes, ModalResult.No, ModalResult.Cancel],
    [MessageBoxButtons.YesNo]: [ModalResult.Yes, ModalResult.No],
    [MessageBoxButtons.RetryCancel]: [ModalResult.Retry, ModalResult.Cancel]
};
function describeMessageBoxButton(result) {
    const descriptor = MESSAGE_BOX_BUTTON[result] ?? MESSAGE_BOX_BUTTON[ModalResult.Ok];
    return { result, ...descriptor };
}

/** DOM id for the config-driven message-box title (used with aria-labelledby). */
const MESSAGE_BOX_TITLE_ID = 'mdlr-message-box-title';
/** DOM id for the config-driven message-box body (used with aria-describedby). */
const MESSAGE_BOX_BODY_ID = 'mdlr-message-box-body';
/**
 * A Bootstrap-styled message box. Use it two ways:
 *
 * 1. Config-driven — `modalieur.messageBox({ title, message, buttons })`.
 * 2. Content projection — place `<mdlr-message-box>` in your own component and
 *    project `[mbHeader]`, `[mbBody]`, `[mbFooter]`.
 */
class MessageBoxDialog extends ModalContent {
    Result = ModalResult;
    titleId = MESSAGE_BOX_TITLE_ID;
    bodyId = MESSAGE_BOX_BODY_ID;
    options = inject(MODAL_DATA, { optional: true }) ?? {};
    get title() {
        return this.options.title ?? '';
    }
    get message() {
        return this.options.message ?? '';
    }
    get buttons() {
        return MESSAGE_BOX_BUTTON_SETS[this.options.buttons ?? MessageBoxButtons.OK].map(describeMessageBoxButton);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.2", ngImport: i0, type: MessageBoxDialog, deps: null, target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "22.0.2", type: MessageBoxDialog, isStandalone: true, selector: "mdlr-message-box", usesInheritance: true, ngImport: i0, template: `
    <div class="modal-header">
      <ng-content select="[mbHeader]">
        <h5 class="modal-title" [attr.id]="titleId">{{ title }}</h5>
        <button type="button" class="btn-close" aria-label="Close" (click)="close(Result.Cancel)"></button>
      </ng-content>
    </div>
    <div class="modal-body" [attr.id]="bodyId">
      <ng-content select="[mbBody]">{{ message }}</ng-content>
    </div>
    <div class="modal-footer">
      <ng-content select="[mbFooter]">
        @for (button of buttons; track button.result) {
          <button type="button" class="btn {{ button.cssClass }}" (click)="close(button.result)">
            {{ button.label }}
          </button>
        }
      </ng-content>
    </div>
  `, isInline: true, changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.2", ngImport: i0, type: MessageBoxDialog, decorators: [{
            type: Component,
            args: [{
                    selector: 'mdlr-message-box',
                    standalone: true,
                    changeDetection: ChangeDetectionStrategy.OnPush,
                    template: `
    <div class="modal-header">
      <ng-content select="[mbHeader]">
        <h5 class="modal-title" [attr.id]="titleId">{{ title }}</h5>
        <button type="button" class="btn-close" aria-label="Close" (click)="close(Result.Cancel)"></button>
      </ng-content>
    </div>
    <div class="modal-body" [attr.id]="bodyId">
      <ng-content select="[mbBody]">{{ message }}</ng-content>
    </div>
    <div class="modal-footer">
      <ng-content select="[mbFooter]">
        @for (button of buttons; track button.result) {
          <button type="button" class="btn {{ button.cssClass }}" (click)="close(button.result)">
            {{ button.label }}
          </button>
        }
      </ng-content>
    </div>
  `
                }]
        }] });

/**
 * Opens Bootstrap-styled modals on top of Angular CDK `Dialog` and exposes the
 * result reactively. The modal is a regular component; close it from inside via
 * `ModalContent` helpers (or by injecting `ModalRef`).
 */
class ModalieurService {
    cdkDialog = inject(Dialog);
    modalieurConfig = signal(inject(MODALIEUR_CONFIG, { optional: true }) ?? MODALIEUR_DEFAULTS, /* @ts-ignore */
    ...(ngDevMode ? [{ debugName: "modalieurConfig" }] : /* istanbul ignore next */ []));
    /**
     * Opens a modal and emits its outcome when it closes. `TIn` is the input data
     * type (from `config.data`); the result-data type is inferred from the
     * component's `ModalContent` base.
     */
    show(component, config) {
        return this.showAndReturnRef(component, config).closed$;
    }
    /**
     * Opens a modal that auto-closes on the **first emission** from `until$`,
     * regardless of value (`false`, `0`, and `''` all count).
     *
     * Use this for timers, one-shot events, or "close when anything happens".
     * For "close when ready", use {@link showUntilCondition} instead.
     *
     * Closes with {@link ModalResult.AutoClose}.
     */
    showUntil(component, until$, config) {
        const ref = this.showAndReturnRef(component, config);
        until$.pipe(take(1), takeUntil(ref.closed$)).subscribe(() => ref.close(ModalResult.AutoClose));
        return ref.closed$;
    }
    /**
     * Opens a modal that auto-closes on the **first truthy** emission from
     * `condition$`. Falsy values (`false`, `0`, `''`, `null`, `undefined`) are
     * ignored until a truthy value arrives.
     *
     * Use this for async readiness signals (e.g. `saveComplete$`, `loaded$`).
     * For "close on any emission", use {@link showUntil} instead.
     *
     * Closes with {@link ModalResult.AutoClose}.
     */
    showUntilCondition(component, condition$, config) {
        const ref = this.showAndReturnRef(component, config);
        condition$.pipe(filter(Boolean), take(1), takeUntil(ref.closed$)).subscribe(() => ref.close(ModalResult.AutoClose));
        return ref.closed$;
    }
    /** Opens a modal and returns its `ModalRef` for programmatic control. */
    showAndReturnRef(component, config) {
        const merged = { ...this.modalieurConfig(), ...config };
        const dialogRef = this.cdkDialog.open(component, this.toDialogConfig(merged));
        return new ModalRef(dialogRef);
    }
    /**
     * Opens a config-driven {@link MessageBoxDialog} and emits only the
     * `ModalResult` (not the full `ModalOutcome`).
     */
    messageBox(options, config) {
        return this.show(MessageBoxDialog, { ...this.withMessageBoxA11y(config), data: options }).pipe(map(outcome => outcome.result));
    }
    /** Yes / No confirmation. Shorthand for `messageBox` with `MessageBoxButtons.YesNo`. */
    confirm(title, message, config) {
        return this.messageBox({ title, message, buttons: MessageBoxButtons.YesNo }, config);
    }
    /** Single OK button alert. Shorthand for `messageBox` with `MessageBoxButtons.OK`. */
    alert(title, message, config) {
        return this.messageBox({ title, message, buttons: MessageBoxButtons.OK }, config);
    }
    toDialogConfig(config) {
        const dialogConfig = {
            data: config.data,
            disableClose: config.dismissible === false,
            hasBackdrop: config.backdrop !== false,
            backdropClass: ['cdk-overlay-dark-backdrop', 'mdlr-modal-backdrop'],
            panelClass: 'mdlr-modal-pane',
            ariaLabel: config.ariaLabel,
            ariaLabelledBy: config.ariaLabelledBy,
            ariaDescribedBy: config.ariaDescribedBy,
            providers: [
                { provide: MODAL_DATA, useValue: config.data ?? null },
                { provide: ModalRef, useFactory: () => new ModalRef(inject(DialogRef)) }
            ]
        };
        if (!config.unstyled) {
            dialogConfig.container = {
                type: BootstrapDialogContainer,
                providers: () => [{ provide: MODALIEUR_CONFIG, useValue: config }]
            };
        }
        return dialogConfig;
    }
    withMessageBoxA11y(config) {
        return {
            ...config,
            ariaLabelledBy: config?.ariaLabelledBy ?? MESSAGE_BOX_TITLE_ID,
            ariaDescribedBy: config?.ariaDescribedBy ?? MESSAGE_BOX_BODY_ID
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "22.0.2", ngImport: i0, type: ModalieurService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "22.0.2", ngImport: i0, type: ModalieurService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "22.0.2", ngImport: i0, type: ModalieurService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/*
 * Public API Surface of ngx-modalieur
 */

/**
 * Generated bundle index. Do not edit.
 */

export { BootstrapDialogContainer, MESSAGE_BOX_BODY_ID, MESSAGE_BOX_TITLE_ID, MODALIEUR_CONFIG, MODALIEUR_DEFAULTS, MODAL_DATA, MessageBoxButtons, MessageBoxDialog, ModalContent, ModalRef, ModalResult, ModalieurService, provideModalieur };
//# sourceMappingURL=ngx-modalieur.mjs.map
